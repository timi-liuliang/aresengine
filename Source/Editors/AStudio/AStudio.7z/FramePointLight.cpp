#include <Engine/RenderSystem/AresLight.h>
#include "FramePointLight.h"
#include "Logic.h"
#include <ostream>

using namespace Ares;

namespace QT_UI
{
	// ���캯��
	CFramePointLight::CFramePointLight( QWidget* parent)
		: QFrame( parent)
	{
		setupUi( this);

		connect( m_color0, SIGNAL(textChanged(QString)), this, SLOT(UpdateLightColor()));
		connect( m_color1, SIGNAL(textChanged(QString)), this, SLOT(UpdateLightColor()));
		connect( m_color2, SIGNAL(textChanged(QString)), this, SLOT(UpdateLightColor()));
		connect( m_att0,   SIGNAL(textChanged(QString)), this, SLOT(UpdateAttenuate()));
		connect( m_att1,   SIGNAL(textChanged(QString)), this, SLOT(UpdateAttenuate()));
		connect( m_att2,   SIGNAL(textChanged(QString)), this, SLOT(UpdateAttenuate()));
	}

	// Widget management functions
	void CFramePointLight::setVisible(bool visible)
	{
		QFrame::setVisible( visible);

		if( visible)
			UpdateShow();
	}

	static QString FtoA( float f)
	{
		ostringstream oss;

		oss << f;

		return oss.str().c_str();
	}

	// ������ʵ��
	void CFramePointLight::UpdateShow()
	{/*
		 SPtr<Entity> tEntity = g_pLogic->GetEntityEditLogic()->GetCurrEntity();
		 if( tEntity && tEntity->GetDetailType() == Entity::EM_DT_LIGHTPOINT)
		 {
			 ILightPoint* pointLight = (ILightPoint*)tEntity.get();

			 const Vector4& color = pointLight->GetColor();
			 const Vector3& atten = pointLight->GetAttenuate();
			 const Vector3& pos   = pointLight->GetSceneNode()->GetPositon();

			 m_color0->setText( FtoA(color.x));
			 m_color1->setText( FtoA(color.y));
			 m_color2->setText( FtoA(color.z));

			 m_pos0->setText( FtoA(pos.x));
			 m_pos1->setText( FtoA(pos.y));
			 m_pos2->setText( FtoA(pos.z));

			 m_att0->setText( FtoA( atten.x));
			 m_att1->setText( FtoA( atten.y));
			 m_att2->setText( FtoA( atten.z));
		 }*/
	}

	// ���¹�Դ��ɫ
	void CFramePointLight::UpdateLightColor()
	{/*
		 SPtr<Entity> tEntity = g_pLogic->GetEntityEditLogic()->GetCurrEntity();
		 if( tEntity && tEntity->GetDetailType() == Entity::EM_DT_LIGHTPOINT)
		 {
			 float r = m_color0->text().toFloat();
			 float g = m_color1->text().toFloat();
			 float b = m_color2->text().toFloat();
 
			 ILightPoint* pointLight = (ILightPoint*)tEntity.get();
			 pointLight->SetColor( r, g, b);
		 }*/
	}

	// ���¹�Դ����
	void CFramePointLight::UpdateAttenuate()
	{/*
		SPtr<Entity> tEntity = g_pLogic->GetEntityEditLogic()->GetCurrEntity();
		if( tEntity && tEntity->GetDetailType() == Entity::EM_DT_LIGHTPOINT)
		{
			float attx	 = m_att0->text().toFloat();
			float atty	 = m_att1->text().toFloat();
			float attz	 = m_att2->text().toFloat();

			ILightPoint* pointLight = (ILightPoint*)tEntity.get();
			pointLight->SetAttenuate( attx, atty, attz);
		}*/
	}
}